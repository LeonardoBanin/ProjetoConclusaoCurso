function navigateToPage() {
    // Função para navegar para outra página (exemplo)
    window.location.href = "";
}

function goToHomePage() {
    // Remove o alerta e apenas redireciona para a página inicial
    window.location.href = "http://127.0.0.1:5500/FlexFood-Site/tela-home/index.html"; // Substitua "home.html" pelo caminho da sua página inicial
}
